USE [ProvaDeConceito]
GO

/******************************************************************/
/*	Trecho de Rollback do script:

DROP TABLE [ProvaDeConceito].[dbo].[ContatoGrupo];
GO
DROP TABLE [ProvaDeConceito].[dbo].[Grupo];
GO
DROP TABLE [ProvaDeConceito].[dbo].[ContatoEndereco];
GO
DROP TABLE [ProvaDeConceito].[dbo].[Contato];
GO

*/

/******************************************************************/
/* TABELA DE CONTATOS */

CREATE TABLE [dbo].[Contato](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nome] [varchar](50) NOT NULL,
	[Email] [varchar](100) NULL,
	[Telefone] [varchar](15) NULL,
	[Situacao] [char](1) NULL
)
GO

ALTER TABLE [dbo].[Contato] ADD CONSTRAINT [PK_Contato] PRIMARY KEY CLUSTERED ([Id] ASC)
GO

/******************************************************************/
/* TABELA DE ENDERE�OS DOS CONTATOS */

CREATE TABLE [dbo].[ContatoEndereco](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[IdContato] [int] NOT NULL,
	[Logradouro] [varchar](100) NOT NULL,
	[CEP] [varchar](10) NULL,
	[Bairro] [varchar](100) NULL,
	[Cidade] [varchar](100) NULL,
	[Estado] [char](2) NULL,
	[Pais] [varchar](100) NULL
)
GO

ALTER TABLE [dbo].[ContatoEndereco] ADD CONSTRAINT [PK_ContatoEndereco] PRIMARY KEY CLUSTERED ([Id] ASC)
GO

ALTER TABLE [dbo].[ContatoEndereco] ADD CONSTRAINT [FK_Contato_ContatoEndereco] FOREIGN KEY([IdContato]) REFERENCES [dbo].[Contato] ([Id])
GO

/******************************************************************/
/* TABELA PARA AGRUPAR OS CONTATOS */

CREATE TABLE [dbo].[Grupo](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Titulo] [varchar](100) NULL,
	[Descricao] [varchar](200) NULL,
	[Situacao] [char](1) NULL
)
GO

ALTER TABLE [dbo].[Grupo] ADD CONSTRAINT [PK_Grupo] PRIMARY KEY CLUSTERED ([Id] ASC)
GO

CREATE TABLE [dbo].[ContatoGrupo](
	[IdGrupo] [int] NOT NULL,
	[IdContato] [int] NOT NULL
)
GO

ALTER TABLE [dbo].[ContatoGrupo] ADD CONSTRAINT [FK_Grupo_ContatoGrupo] FOREIGN KEY([IdGrupo]) REFERENCES [dbo].[Grupo] ([Id])
GO

ALTER TABLE [dbo].[ContatoGrupo] ADD CONSTRAINT [FK_Contato_ContatoGrupo] FOREIGN KEY([IdContato]) REFERENCES [dbo].[Contato] ([Id])
GO

ALTER TABLE [dbo].[ContatoGrupo] ADD CONSTRAINT [PK_ContatoGrupo] PRIMARY KEY CLUSTERED ([IdGrupo], [IdContato] ASC)
GO

