namespace LDSoft.ProvaDeConceito.Infrastructure.Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CriacaoDoBanco : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Envolvido",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        IdUsuario = c.Int(nullable: false),
                        Apelido = c.String(nullable: false, maxLength: 150, unicode: false),
                        Email = c.String(maxLength: 254, unicode: false),
                        RazaoSocial = c.String(maxLength: 150, unicode: false),
                        CNPJ = c.String(maxLength: 50, unicode: false),
                        CPF = c.Long(nullable: false),
                        Pasta = c.String(maxLength: 30, unicode: false),
                        Pessoa = c.String(maxLength: 10, unicode: false),
                        DescontoINPI = c.Boolean(),
                        ObjetoSocial = c.String(unicode: false),
                        Observacao = c.String(unicode: false),
                        NumeroDeRegistro = c.String(maxLength: 15, unicode: false),
                        Celular = c.String(maxLength: 20, unicode: false),
                        DDD = c.String(maxLength: 3, unicode: false),
                        Logradouro = c.String(maxLength: 150, unicode: false),
                        Complemento = c.String(maxLength: 150, unicode: false),
                        Numero = c.String(maxLength: 50, unicode: false),
                        Bairro = c.String(maxLength: 150, unicode: false),
                        Cidade = c.String(maxLength: 150, unicode: false),
                        Uf = c.Int(),
                        Cep = c.Long(),
                        Grupo = c.String(maxLength: 15, unicode: false),
                        IdAdvogado = c.Int(),
                        IdIdioma = c.Int(),
                        IdNacionalidade = c.Int(),
                        Status = c.Int(nullable: false),
                        DataDeInclusao = c.DateTime(nullable: false),
                        DataDeAlteracao = c.DateTime(),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Email, unique: true, name: "IX_EmailEnvolvido")
                .Index(t => t.CPF, unique: true, name: "IX_CPFEnvolvido");
            
        }
        
        public override void Down()
        {
            DropIndex("dbo.Envolvido", "IX_CPFEnvolvido");
            DropIndex("dbo.Envolvido", "IX_EmailEnvolvido");
            DropTable("dbo.Envolvido");
        }
    }
}
