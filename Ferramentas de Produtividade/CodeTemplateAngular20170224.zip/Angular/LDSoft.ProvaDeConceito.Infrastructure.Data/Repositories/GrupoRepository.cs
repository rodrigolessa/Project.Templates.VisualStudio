﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LDSoft.Comum.Domain;
using LDSoft.ProvaDeConceito.Domain.Entities;
using LDSoft.ProvaDeConceito.Domain.Repositories;
using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork;

namespace LDSoft.ProvaDeConceito.Infrastructure.Data.Repositories
{
    public partial class GrupoRepository : Repository<Grupo>, IGrupoRepository
    {
        #region Construtor

        public GrupoRepository(IQueryableUnitOfWork unitOfWork)
            : base(unitOfWork) { }

        #endregion
    }
}
