﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration.Conventions;

using LDSoft.Comum.Domain;
using LDSoft.Comum.Infrastructure;
using LDSoft.ProvaDeConceito.Domain.Entities;
//using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork.Mapping;
using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork.EntityTypeConfigurations;

namespace LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork
{
    public class MainUnitOfWork : DbContext, IQueryableUnitOfWork
    {
        public MainUnitOfWork()
            : base("LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork.MainUnitOfWork")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        #region IDbSet Members

        //IDbSet<Contato> _contatos;
        //public IDbSet<Contato> Contatos
        //{
        //    get
        //    {
        //        if (_contatos == null)
        //            _contatos = base.Set<Contato>();

        //        return _contatos;
        //    }
        //}

        //IDbSet<ContatoEndereco> _contatoEnderecos;
        //public IDbSet<ContatoEndereco> ContatoEnderecos
        //{
        //    get
        //    {
        //        if (_contatoEnderecos == null)
        //            _contatoEnderecos = base.Set<ContatoEndereco>();

        //        return _contatoEnderecos;
        //    }
        //}

        //IDbSet<Grupo> _grupos;
        //public IDbSet<Grupo> Grupos
        //{
        //    get
        //    {
        //        if (_grupos == null)
        //            _grupos = base.Set<Grupo>();

        //        return _grupos;
        //    }
        //}

        IDbSet<Envolvido> _envolvido;
        public IDbSet<Envolvido> Envolvidos
        {
            get
            {
                if (_envolvido == null)
                    _envolvido = base.Set<Envolvido>();

                return _envolvido;
            }
        }

        //public System.Data.Entity.DbSet<LDSoft.ProvaDeConceito.Domain.Entities.Envolvido> Envolvidoes { get; set; }

        #endregion

        #region IQueryableUnitOfWork Members

        public IDbSet<TEntity> CreateSet<TEntity>() where TEntity : class
        {
            return base.Set<TEntity>();
        }

        public void Attach<TEntity>(TEntity item) where TEntity : class
        {
            base.Entry<TEntity>(item).State = System.Data.Entity.EntityState.Unchanged;
        }

        public void SetModified<TEntity>(TEntity item) where TEntity : class
        {
            base.Entry<TEntity>(item).State = System.Data.Entity.EntityState.Modified;
        }

        public void ApplyCurrentValues<TEntity>(TEntity original, TEntity current) where TEntity : class
        {
            base.Entry<TEntity>(original).CurrentValues.SetValues(current);
        }

        public int Commit()
        {
            return base.SaveChanges();
        }

        public void CommitAndRefreshChanges()
        {
            bool saveFailed = false;

            do
            {
                try
                {
                    base.SaveChanges();

                    saveFailed = false;

                }
                catch (DbUpdateConcurrencyException ex)
                {
                    saveFailed = true;

                    ex.Entries.ToList()
                              .ForEach(entry =>
                              {
                                  entry.OriginalValues.SetValues(entry.GetDatabaseValues());
                              });

                }
            } while (saveFailed);
        }

        public void RollbackChanges()
        {
            base.ChangeTracker.Entries()
                              .ToList()
                              .ForEach(entry => entry.State = System.Data.Entity.EntityState.Unchanged);
        }

        public IEnumerable<TEntity> ExecuteQuery<TEntity>(string sqlQuery, params object[] parameters)
        {
            return base.Database.SqlQuery<TEntity>(sqlQuery, parameters);
        }

        public int ExecuteCommand(string sqlCommand, params object[] parameters)
        {
            return base.Database.ExecuteSqlCommand(sqlCommand, parameters);
        }

        #endregion

        #region DbContext Overrides

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //Remove unused conventions
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            modelBuilder.Conventions.Remove<OneToManyCascadeDeleteConvention>();
            modelBuilder.Conventions.Remove<ManyToManyCascadeDeleteConvention>();

            modelBuilder.Properties<string>()
                .Configure(p => p.HasColumnType("varchar"));

            modelBuilder.Properties<string>()
                .Configure(p => p.HasMaxLength(50));

            //Add entity configurations in a structured way using 'TypeConfiguration’ classes
            //modelBuilder.Configurations.Add(new ContatoMap());
            //modelBuilder.Configurations.Add(new ContatoEnderecoMap());
            //modelBuilder.Configurations.Add(new GrupoMap());
            modelBuilder.Configurations.Add(new EnvolvidoTypeConfiguration());
        }

        #endregion
    }
}
