using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using LDSoft.ProvaDeConceito.Domain.Entities;

namespace LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork.Mapping
{
    public class ContatoEnderecoMap : EntityTypeConfiguration<ContatoEndereco>
    {
        public ContatoEnderecoMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.Logradouro)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.CEP)
                .HasMaxLength(10);

            this.Property(t => t.Bairro)
                .HasMaxLength(100);

            this.Property(t => t.Cidade)
                .HasMaxLength(100);

            this.Property(t => t.Estado)
                .IsFixedLength()
                .HasMaxLength(2);

            this.Property(t => t.Pais)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("ContatoEndereco");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.IdContato).HasColumnName("IdContato");
            this.Property(t => t.Logradouro).HasColumnName("Logradouro");
            this.Property(t => t.CEP).HasColumnName("CEP");
            this.Property(t => t.Bairro).HasColumnName("Bairro");
            this.Property(t => t.Cidade).HasColumnName("Cidade");
            this.Property(t => t.Estado).HasColumnName("Estado");
            this.Property(t => t.Pais).HasColumnName("Pais");

            // Relationships
            this.HasRequired(t => t.Contato)
                .WithMany(t => t.ContatoEnderecoes)
                .HasForeignKey(d => d.IdContato);

        }
    }
}
