﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.Infrastructure.Annotations;
using System.Text;
using System.Threading.Tasks;
using LDSoft.Comum.Domain.Entities;
using LDSoft.Comum.Domain.Entities.ValueObjects;
using LDSoft.ProvaDeConceito.Domain.Entities;

namespace LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork.EntityTypeConfigurations
{
    public class EnvolvidoTypeConfiguration : EntityTypeConfiguration<Envolvido>
    {
        public EnvolvidoTypeConfiguration()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Table & Column Mappings
            this.ToTable("Envolvido");

            Property(x => x.IdUsuario)
                .HasColumnName("IdUsuario")
                .HasColumnType("int");

            //public const int ApelidoMaxLength = 150;
            Property(x => x.Apelido)
                .HasColumnName("Apelido")
                .HasMaxLength(Envolvido.ApelidoMaxLength)
                .IsRequired();

            Property(x => x.Email.Endereco)
                .HasColumnName("Email")
                .HasMaxLength(Email.EnderecoMaxLength)
                .HasColumnAnnotation(IndexAnnotation.AnnotationName,
                    new IndexAnnotation(new IndexAttribute("IX_EmailEnvolvido", 3) { IsUnique = true }));

            //public const int RazaoSocialMaxLength = 150;
            Property(x => x.RazaoSocial)
                .HasColumnName("RazaoSocial")
                .HasMaxLength(Envolvido.RazaoSocialMaxLength);
            
            Property(x => x.CNPJ);

            Property(x => x.CPF.Codigo)
                .HasColumnName("CPF")
                .HasColumnAnnotation(IndexAnnotation.AnnotationName,
                    new IndexAnnotation(new IndexAttribute("IX_CPFEnvolvido", 1) { IsUnique = true }));

            //public const int PastaMaxLength = 30;
            Property(x => x.Pasta)
                .HasColumnName("Pasta")
                .HasMaxLength(Envolvido.PastaMaxLength);

            //public const int PessoaMaxLength = 10;
            Property(x => x.Pessoa)
                .HasColumnName("Pessoa")
                .HasMaxLength(Envolvido.PessoaMaxLength);
            
            Property(x => x.DescontoINPI)
                .HasColumnName("DescontoINPI");

            Property(x => x.ObjetoSocial)
                .HasColumnName("ObjetoSocial")
                .HasColumnType("varchar(max)")
                .IsOptional();

            Property(x => x.Observacao)
                .HasColumnName("Observacao")
                .HasColumnType("varchar(max)")
                .IsOptional();

            //public const int NumeroDeRegistroMaxLength = 15;
            Property(x => x.NumeroDeRegistro)
                .HasColumnName("NumeroDeRegistro")
                .HasMaxLength(Envolvido.NumeroDeRegistroMaxLength);

            Property(x => x.Celular.DDD)
                .HasColumnName("DDD")
                .HasMaxLength(Telefone.DDDMaxLength);

            Property(x => x.Celular.Numero)
                .HasColumnName("Celular")
                .HasMaxLength(Telefone.NumeroMaxLength);

            ////////////////////////////////////////////////////////////////
            // ENDEREÇO

            Property(x => x.Endereco.Bairro)
                .HasColumnName("Bairro")
                .HasMaxLength(Endereco.BairroMaxLength);

            Property(x => x.Endereco.Cidade)
                .HasColumnName("Cidade")
                .HasMaxLength(Endereco.CidadeMaxLength);

            Property(x => x.Endereco.Complemento)
                .HasColumnName("Complemento")
                .HasMaxLength(Endereco.ComplementoMaxLength);

            Property(x => x.Endereco.Logradouro)
                .HasColumnName("Logradouro")
                .HasMaxLength(Endereco.LogradouroMaxLength);

            Property(x => x.Endereco.Numero)
                .HasColumnName("Numero")
                .HasMaxLength(Endereco.NumeroMaxLength);

            Property(x => x.Endereco.Uf)
                .HasColumnName("Uf");

            Property(x => x.Endereco.Cep.CepCod)
                .HasColumnName("Cep");

            //public const int GrupoMaxLength = 15;
            Property(x => x.Grupo)
                .HasColumnName("Grupo")
                .HasMaxLength(Envolvido.GrupoMaxLength);

            Property(x => x.IdAdvogado)
                .HasColumnName("IdAdvogado");
            Property(x => x.IdIdioma)
                .HasColumnName("IdIdioma");
            Property(x => x.IdNacionalidade)
                .HasColumnName("IdNacionalidade");

            Property(x => x.Status)
                .HasColumnName("Status");

            Property(x => x.DataDeInclusao)
                .HasColumnName("DataDeInclusao");
            Property(x => x.DataDeAlteracao)
                .HasColumnName("DataDeAlteracao");
        }
    }
}
