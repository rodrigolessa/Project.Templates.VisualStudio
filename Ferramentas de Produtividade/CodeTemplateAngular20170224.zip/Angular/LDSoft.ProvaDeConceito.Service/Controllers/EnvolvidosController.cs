﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

using LDSoft.Comum.Domain;
using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork;
using LDSoft.ProvaDeConceito.Infrastructure.Data.Repositories;
using LDSoft.ProvaDeConceito.Domain.Entities;
using LDSoft.ProvaDeConceito.Domain.Repositories;
using LDSoft.ProvaDeConceito.Domain.Services;

namespace LDSoft.ProvaDeConceito.Service.Controllers
{
    public class EnvolvidosController : ApiController
    {
        private IQueryableUnitOfWork _unit;
        private IEnvolvidoRepository _repository;
        //private IEnvolvidoService _service;

        public EnvolvidosController() {
            _unit = new MainUnitOfWork();
            _repository = new EnvolvidoRepository(_unit);
            //_service = new EnvolvidoService(_repository, _unit);
            // TODO: Utilizar DI e IoC com API
        }

        // GET: api/Envolvidos
        public IEnumerable<Envolvido> GetEnvolvidos()
        {
            return _repository.GetAll();
        }

        // GET: api/Envolvidos/5
        [ResponseType(typeof(Envolvido))]
        public IHttpActionResult GetEnvolvido(int id)
        {
            Envolvido envolvido = _repository.Get(id);
            if (envolvido == null)
            {
                return NotFound();
            }

            return Ok(envolvido);
        }

        // PUT: api/Envolvidos/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutEnvolvido(int id, Envolvido envolvido)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != envolvido.Id)
            {
                return BadRequest();
            }

            _repository.Modify(envolvido);

            try
            {
                _unit.Commit();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!EnvolvidoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/Envolvidos
        [ResponseType(typeof(Envolvido))]
        public IHttpActionResult PostEnvolvido(Envolvido envolvido)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _repository.Add(envolvido);
            _unit.Commit();

            return CreatedAtRoute("DefaultApi", new { id = envolvido.Id }, envolvido);
        }

        // DELETE: api/Envolvidos/5
        [ResponseType(typeof(Envolvido))]
        public IHttpActionResult DeleteEnvolvido(int id)
        {
            Envolvido envolvido = _repository.Get(id);
            if (envolvido == null)
            {
                return NotFound();
            }

            _repository.Remove(envolvido);
            _unit.Commit();

            return Ok(envolvido);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _repository.Dispose();
            }

            base.Dispose(disposing);
        }

        private bool EnvolvidoExists(int id)
        {
            return _repository.GetFiltered(e => e.Id == id).Any();
        }
    }
}