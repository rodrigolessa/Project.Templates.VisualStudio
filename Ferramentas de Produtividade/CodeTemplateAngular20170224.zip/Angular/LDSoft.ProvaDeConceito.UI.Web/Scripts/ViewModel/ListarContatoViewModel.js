﻿var contatoViewModel = function (id, nome, email, telefone, situacao, listaEnderecos, listaGrupos) {
    var vm = this;
    vm.Id = ko.observable(id || 0);
    vm.Nome = ko.observable(nome || '');
    vm.Email = ko.observable(email || '');
    vm.Telefone = ko.observable(telefone || '');
    vm.Situacao = ko.observable(situacao || '');
    vm.Enderecos = ko.observableArray([]);
    vm.Grupos = ko.observableArray($.map(listaGrupos, function (x) { return new grupoViewModel(x, '', '', '') }) || []);
}

var grupoViewModel = function(id, titulo, descricao, situacao) {
    var gvm = this;
    gvm.Id = ko.observable(id || 0);
    gvm.Titulo = ko.observable(titulo || '');
    gvm.Descricao = ko.observable(descricao || '');
    gvm.Situacao = ko.observable(situacao || '');
}

// Função principal para ViewModel
/////////////////////////////////////////
var ListarContatoViewModel = function (data) {

    // Propriedades
    /////////////////////////////////////////
    var self = new ViewModelBase(data);

    self.lista = ko.observableArray([]);
    self.listaDeGrupos = ko.observableArray([]);
    self.nome = ko.observable("");
    self.gruposSelecionados = ko.observableArray([]);

    Pace.track(function () {

        app.get(config.urlAPI, function (allData) {
            self.lista(allData);
        });

        app.get(config.urlGrupoAPI, function (allData) {
            self.listaDeGrupos(allData);
        });

    });

    // Métodos
    /////////////////////////////////////////
    self.filtrar = function () {

        self.Mensagens.removeAll();
        self.lista.removeAll();

        if (self.nome() == null || self.nome().trim().length < 3) {
            self.exibirMensagem(false, validacaoGenerica.minimoObrigatorio(" o Nome do Contato ", "3"));
            return false;
        }

        Pace.track(function () {
            app.get(config.urlAPI, { nome: self.nome() }, function (allData) {
                self.lista(allData);
                if (self.lista().length == 0)
                    self.exibirMensagemRegistrosNaoEncontrados();
            });
        });
    } // self.filtrar

    self.criar = function () {
        window.location = config.urlCriar;
    } // self.criar

    self.editar = function (data) {
        window.location = config.urlEditar + "/" + data.Id;
    } // self.Editar

    self.abrirAddGrupo = function () {
        var chkArray = [];

        $(".check-item:checked").each(function () {
            chkArray.push($(this).val());
        });

        if (chkArray.length > 0) {
            $("#modalAddGrupo").modal("show");
        }
    } //self.abrirAddGrupo

    self.fecharAddGrupo = function () {
        $("#modalAddGrupo").modal("hide");
    } //self.fecharAddGrupo

    self.editarEmLote = function () {
        var chkArray = [];

        $(".check-item:checked").each(function () {
            chkArray.push($(this).val());
        });

        if (chkArray.length > 0) {

            Pace.track(function () {

                var prm = ko.observableArray($.map(chkArray, function (item) { return new contatoViewModel(item, '', '', '', '', null, self.gruposSelecionados()) }));

                app.post(config.urlContatoGrupoAPI, prm, function (allData) {
                    self.HasSuccess(allData.Response);
                    self.Mensagens(allData.Messages);
                    //TODO: Melhorar implementação!
                    app.get(config.urlAPI, function (allData) {
                        self.lista(allData);
                    });
                });

            });
        }

        self.fecharAddGrupo();
    } //self.editarEmLote

    self.excluir = function () {
        var chkArray = [];

        $(".check-item:checked").each(function () {
            chkArray.push($(this).val());
        });

        if (chkArray.length > 0) {
            Pace.track(function () {
                app.delete(config.urlAPI, chkArray, function (allData) {
                    self.HasSuccess(allData.Response);
                    self.Mensagens(allData.Messages);
                    //TODO: Melhorar implementação!
                    app.get(config.urlAPI, function (allData) {
                        self.lista(allData);
                        //if (self.nome() != null || self.nome().trim().length > 2)
                        //self.filtrar();
                    });
                });
            });
        }
    } //self.excluir

    self.modalExclusao = new modalDeExclusaoDTO('modalExclusao');
    self.modalExclusao.texto('Tem certeza que deseja realizar a exclusão do Contato { Nome }?');
    self.modalExclusao.confirma = function () {
        Pace.track(function () {
            var m = self.modalExclusao.item;
            app.delete(config.urlAPI + '/' + m.Id, {}, function (d) {
                self.businessResponse(d);
                if (d.Response) {
                    self.lista.remove(m);
                }
            });
        });
    } // self.modalExclusao.confirma

    return self;
}