﻿var ResourceViewModel = function (data) {

    self.listaDeResource = ko.observableArray([]);

    self.titulo = ko.observable("");

    app.get(app.config.urlInfoResource + "/GetResource", function (resData) {
        self.listaDeResource = ko.mapping.fromJS(resData);

        //self.titulo(self.getRes('TextoCabecalhoLeilao'));
    });

    self.getRes = function (chave) {
        var res = ko.utils.arrayFilter(self.listaDeResource(), function (item) {
            return item.Chave() == chave;
        })[0]
        return res.Valor();
    }

    self.info = function (event, chave) {
        var objeto = $(event.target);
        objeto.attr('data-original-title', self.getRes(chave));
        if (event ? event.originalEvent : false) {
            objeto.mouseover();
        }
        return true;
    };

    return self;
}