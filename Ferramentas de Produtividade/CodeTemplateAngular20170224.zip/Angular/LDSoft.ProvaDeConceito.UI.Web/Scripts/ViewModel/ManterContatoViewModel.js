﻿// Representação da ViewModel com as propriedades necessárias
var ManterContatoViewModel = function (data) {

    // Propriedades
    /////////////////////////////////////////
    var self = new ViewModelBase(data);

    self.titulo = ko.computed(function () { if (self.Id() == 0) return "Criar"; else return "Editar"; });
    self.ListaDeSituacao = ko.observableArray([]);

    return self;
}