﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LDSoft.ProvaDeConceito.UI.Web.ViewModel
{
    public class EnderecoViewModel : ViewModelBase
    {
        public int Id { get; set; }
        public string Logradouro { get; set; }
        public string CEP { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string Pais { get; set; }
    }
}