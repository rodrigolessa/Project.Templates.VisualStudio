﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LDSoft.ProvaDeConceito.UI.Web.ViewModel
{
    public class ContatoViewModel : ViewModelBase
    {
        public ContatoViewModel()
        {
            this.Enderecos = new List<EnderecoViewModel>();
            this.Grupos = new List<GrupoViewModel>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Situacao { get; set; }
        public string DescricaoDaSituacao { get; set; }
        public List<EnderecoViewModel> Enderecos { get; set; }
        public List<GrupoViewModel> Grupos { get; set; }
    }
}