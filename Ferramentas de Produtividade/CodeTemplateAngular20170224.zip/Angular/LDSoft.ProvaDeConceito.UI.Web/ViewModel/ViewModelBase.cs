﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Threading.Tasks;

using LDSoft.ProvaDeConceito.Domain.Entities.Enum;

namespace LDSoft.ProvaDeConceito.UI.Web.ViewModel
{
    public class ViewModelBase
    {
        #region Propriedades

        public string Titulo { get; set; }
        public TipoDeMensagemEnum TipoDeMensagem {get;set;}
        public List<string> Mensagens { get; set; }
        public bool HasError { get; set; }

        #endregion

        #region Construtores

        public ViewModelBase()
        {
            this.HasError = false;
            this.Mensagens = new List<string>();
        }

        internal ViewModelBase(string mensagem, string titulo, TipoDeMensagemEnum tipoDeMensagem)
        {
            this.Mensagens.Clear();
            this.Mensagens.Add(mensagem);
            this.Titulo = titulo;
            this.TipoDeMensagem = tipoDeMensagem;
            if (tipoDeMensagem == TipoDeMensagemEnum.Success)
                this.HasError = false;
            else
                this.HasError = true;
        }

        #endregion

        #region Métodos Estáticos

        public static ViewModelBase Success(string mensagem, string titulo)
        {
            return new ViewModelBase(mensagem, titulo, TipoDeMensagemEnum.Success);
        }

        public static ViewModelBase Error(string mensagem, string titulo)
        {
            return new ViewModelBase(mensagem, titulo, TipoDeMensagemEnum.Erros);
        }

        public static ViewModelBase Warning(string mensagem, string titulo)
        {
            return new ViewModelBase(mensagem, titulo, TipoDeMensagemEnum.Warning);
        }

        #endregion

        #region Métodos Públicos

        public ViewModelBase DoError(string mensagem, string titulo)
        {
            this.Mensagens.Clear();
            this.Mensagens.Add(mensagem);
            this.Titulo = titulo;
            this.HasError = true;
            this.TipoDeMensagem = TipoDeMensagemEnum.Erros;
            return this;
        }

        #endregion
    }
}