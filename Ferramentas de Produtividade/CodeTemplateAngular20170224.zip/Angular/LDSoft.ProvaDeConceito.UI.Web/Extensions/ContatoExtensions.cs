﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;

using LDSoft.ProvaDeConceito.Domain.Entities;
using LDSoft.ProvaDeConceito.UI.Web.ViewModel;

namespace LDSoft.ProvaDeConceito.UI.Web.Extensions
{
    public static class ContatoExtensions
    {
        public static List<ContatoViewModel> Traduzir(this IEnumerable<Contato> lista)
        {
            return lista.Select(x => x.Traduzir()).ToList();
        }

        public static ContatoViewModel Traduzir(this Contato item)
        {
            Mapper.CreateMap<ContatoEndereco, EnderecoViewModel>();
            //.ForSourceMember(ori => ori.Destruir, x => x.Ignore());
            Mapper.CreateMap<Grupo, GrupoViewModel>();
            Mapper.CreateMap<Contato, ContatoViewModel>()
                .ForMember(x => x.Grupos, vm => vm.MapFrom(ori => ori.Grupoes))
                .ForMember(x => x.Enderecos, vm => vm.MapFrom(ori => ori.ContatoEnderecoes));
            //.ForMember(res => res._destroy, vm => vm.MapFrom(ori => ori.Excluido));
            return Mapper.Map<Contato, ContatoViewModel>(item);
        }

        public static List<Contato> Traduzir(this List<ContatoViewModel> lista)
        {
            return lista.Select(x => x.Traduzir()).ToList();
        }

        public static Contato Traduzir(this ContatoViewModel item)
        {
            Mapper.CreateMap<EnderecoViewModel, ContatoEndereco>();
            //.ForMember(des => des.DescricaoDoTipoDeEndereco, x => x.Ignore())
            //.ForMember(des => des.Destruir, x => x.MapFrom(dto => dto._destroy));
            Mapper.CreateMap<GrupoViewModel, Grupo>();
            Mapper.CreateMap<ContatoViewModel, Contato>()
                .ForMember(des => des.ContatoEnderecoes, x => x.MapFrom(ori => ori.Enderecos))
                .ForMember(des => des.Grupoes, x => x.MapFrom(ori => ori.Grupos));
            return Mapper.Map<ContatoViewModel, Contato>(item);
        }
    }
}