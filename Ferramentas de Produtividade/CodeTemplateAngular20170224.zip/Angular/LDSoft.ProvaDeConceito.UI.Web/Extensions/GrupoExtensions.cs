﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AutoMapper;

using LDSoft.ProvaDeConceito.Domain.Entities;
using LDSoft.ProvaDeConceito.UI.Web.ViewModel;

namespace LDSoft.ProvaDeConceito.UI.Web.Extensions
{
    public static class GrupoExtensions
    {
        public static List<GrupoViewModel> Traduzir(this IEnumerable<Grupo> lista)
        {
            return lista.Select(x => x.Traduzir()).ToList();
        }

        public static GrupoViewModel Traduzir(this Grupo item)
        {
            Mapper.CreateMap<Grupo, GrupoViewModel>();
            return Mapper.Map<Grupo, GrupoViewModel>(item);
        }
    }
}