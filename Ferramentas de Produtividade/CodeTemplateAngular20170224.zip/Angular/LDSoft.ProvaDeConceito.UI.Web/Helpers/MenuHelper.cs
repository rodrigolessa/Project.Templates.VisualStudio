﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;

namespace LDSoft.ProvaDeConceito.UI.Web.Helpers
{
    public static class MenuHelper
    {
        public static string MarcarItemDeMenuComoAtivo(HttpRequestBase request, string pagina)
        {
            if (request.Url.ToString().ToUpper().Contains(pagina.ToUpper()))
                return "active";

            return String.Empty;
        }
    }
}