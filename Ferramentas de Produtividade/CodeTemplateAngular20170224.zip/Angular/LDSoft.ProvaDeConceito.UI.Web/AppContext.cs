﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using Newtonsoft.Json;

//https://en.wikipedia.org/wiki/Proof_of_concept

namespace LDSoft.ProvaDeConceito.UI.Web
{
    public sealed class AppContext
    {
        // Variables
        private static volatile AppContext _instance;
        //private static object syncRoot = new Object();

        // Constructor
        private AppContext()
        {
        }

        // Properties
        public static AppContext Instance
        {
            get
            {
                //if (_instance == null)
                //{
                //    lock (syncRoot)
                //    {
                if (_instance == null)
                    _instance = new AppContext();
                //    }
                //}

                return _instance;
            }
        }

        // Methods
    }
}