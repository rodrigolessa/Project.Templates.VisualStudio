﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using LDSoft.ProvaDeConceito.Domain.Resources;
using System.Globalization;
using System.Resources;
using System.Collections;

namespace LDSoft.ProvaDeConceito.UI.Web.Controllers
{
    public class ResourceAPIController : Controller
    {
        //
        // GET: /ResourceAPI/
        public List<Object> GetResource()
        {
            var lista = new List<Object>();

            HttpCookie cookie = new HttpCookie("Language");
            
             if (cookie != null && cookie.Value != null)
                 if (cookie.Value == "en")
                 {
                    ResourceSet resourceSet = Login_en.ResourceManager.GetResourceSet(CultureInfo.CurrentUICulture, true, true);
                    foreach (DictionaryEntry ent in resourceSet)
                        lista.Add(new { Chave = ent.Key.ToString(), Valor = ent.Value.ToString() });

                 }
                 else 
                 {
                     ResourceSet resourceSet = Login_pt.ResourceManager.GetResourceSet(CultureInfo.CurrentUICulture, true, true);
                     foreach (DictionaryEntry ent in resourceSet)
                     lista.Add(new { Chave = ent.Key.ToString(), Valor = ent.Value.ToString() });

                 }
             else {
                    ResourceSet resourceSet = Login_pt.ResourceManager.GetResourceSet(CultureInfo.CurrentUICulture, true, true);
                    foreach (DictionaryEntry ent in resourceSet)
                        lista.Add(new { Chave = ent.Key.ToString(), Valor = ent.Value.ToString() });             
             }
     
            return lista;
        }
    }
}
