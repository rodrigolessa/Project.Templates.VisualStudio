﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using LDSoft.Comum.Infrastructure;
using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork;
using LDSoft.ProvaDeConceito.Infrastructure.Data.Repositories;
using LDSoft.ProvaDeConceito.Domain.Repositories;
using LDSoft.ProvaDeConceito.Domain.Services;
using LDSoft.ProvaDeConceito.UI.Web.ViewModel;
using LDSoft.ProvaDeConceito.UI.Web.Extensions;

namespace LDSoft.ProvaDeConceito.UI.Web.Controllers
{
    public class GrupoAPIController : SecurityAPIController
    {
        private MainUnitOfWork _unit;
        private IGrupoRepository _grupoRepository;

        public GrupoAPIController()
        {
            _unit = new MainUnitOfWork();
            _grupoRepository = new GrupoRepository(_unit);
        }
    
        // GET api/grupoapi
        public IEnumerable<GrupoViewModel> Get()
        {
            return _grupoRepository.GetAll().Traduzir();
        }

        // GET api/grupoapi/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/grupoapi
        public void Post([FromBody]string value)
        {
        }

        // PUT api/grupoapi/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/grupoapi/5
        public void Delete(int id)
        {
        }
    }
}
