﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using LDSoft.ProvaDeConceito.UI.Web.ViewModel;

namespace LDSoft.ProvaDeConceito.UI.Web.Controllers
{
    public class ContatoController : SecurityController
    {
        //
        // GET: /Contato/

        public ActionResult Index()
        {
            return View();
        }

        //
        // GET: /Contato/Create

        public ActionResult Criar()
        {
            return View("Manter", new ContatoViewModel());
        }

        //
        // GET: /Contato/Edit/5

        public ActionResult Editar(int id)
        {
            return View("Manter", new ContatoViewModel() { Id = id } );
        }
    }
}