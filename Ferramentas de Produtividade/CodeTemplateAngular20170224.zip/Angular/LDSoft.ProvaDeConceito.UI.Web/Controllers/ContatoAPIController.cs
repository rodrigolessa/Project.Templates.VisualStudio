﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using LDSoft.Comum.Infrastructure;
using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork;
using LDSoft.ProvaDeConceito.Infrastructure.Data.Repositories;
using LDSoft.ProvaDeConceito.Domain.Repositories;
using LDSoft.ProvaDeConceito.Domain.Services;
using LDSoft.ProvaDeConceito.UI.Web.ViewModel;
using LDSoft.ProvaDeConceito.UI.Web.Extensions;

namespace LDSoft.ProvaDeConceito.UI.Web.Controllers
{
    public class ContatoAPIController : ApiController
    {
        private MainUnitOfWork _unit;
        private IGrupoRepository _grupoRepository;
        private IContatoRepository _repository;
        private IContatoEnderecoRepository _enderecoRepository;
        private IContatoService _service;

        public ContatoAPIController()
        {
            _unit = new MainUnitOfWork();
            _repository = new ContatoRepository(_unit);
            _grupoRepository = new GrupoRepository(_unit);
            _enderecoRepository = new ContatoEnderecoRepository(_unit);
            _service = new ContatoService(_repository, _grupoRepository, _enderecoRepository, _unit);
        }

        // GET api/contatoapi
        public IEnumerable<ContatoViewModel> Get()
        {
            return _repository.GetAll().Traduzir();
        }

        // GET api/contatoapi/5
        public ContatoViewModel Get(int id)
        {
            return _repository.Get(id).Traduzir();
        }

        // GET api/contatoapi/Rodrigo
        public IEnumerable<ContatoViewModel> Get(string nome)
        {
            return _service.Obter(nome).Traduzir();
        }

        // POST api/contatoapi
        public ContatoViewModel Post(ContatoViewModel contato)
        {
            return contato;
        }

        // POST api/contatoapi
        //public BusinessResponse<bool> Post(List<int> ids, List<int> idGrupos)
        //public BusinessResponse<bool> Post(List<ContatoViewModel> contatos)
        public BusinessResponse<bool> POST(List<ContatoViewModel> contatos)
        {
            //return _service.AssociarGrupos(ids, idGrupos);
            return new BusinessResponse<bool>(true);
        }

        // PUT api/contatoapi/5
        public ContatoViewModel Put(int id, ContatoViewModel contato)
        {
            return contato;
        }

        // DELETE api/contatoapi/5
        public BusinessResponse<bool> Delete(int id)
        {
            return _service.Excluir(id);
        }

        // DELETE api/contatoapi/5,2,3,11
        public BusinessResponse<bool> Delete(List<int> ids)
        {
            return _service.Excluir(ids);
        }
    }
}
