﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using LDSoft.Comum.Infrastructure;
using LDSoft.ProvaDeConceito.Infrastructure.Data.UnitOfWork;
using LDSoft.ProvaDeConceito.Infrastructure.Data.Repositories;
using LDSoft.ProvaDeConceito.Domain.Repositories;
using LDSoft.ProvaDeConceito.Domain.Services;
using LDSoft.ProvaDeConceito.UI.Web.ViewModel;
using LDSoft.ProvaDeConceito.UI.Web.Extensions;

namespace LDSoft.ProvaDeConceito.UI.Web.Controllers
{
    public class ContatoGrupoAPIController : ApiController
    {
        private MainUnitOfWork _unit;
        private IGrupoRepository _grupoRepository;
        private IContatoRepository _repository;
        private IContatoEnderecoRepository _enderecoRepository;
        private IContatoService _service;

        public ContatoGrupoAPIController()
        {
            _unit = new MainUnitOfWork();
            _repository = new ContatoRepository(_unit);
            _grupoRepository = new GrupoRepository(_unit);
            _enderecoRepository = new ContatoEnderecoRepository(_unit);
            _service = new ContatoService(_repository, _grupoRepository, _enderecoRepository, _unit);
        }

        // GET api/contatogrupoapi
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/contatogrupoapi/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/contatogrupoapi
        public BusinessResponse<bool> Post(List<ContatoViewModel> contatos)
        {
            return _service.AssociarGrupos(contatos.Select(x => x.Id).ToList(), contatos.FirstOrDefault().Grupos.Select(x => x.Id).ToList());
        }

        // PUT api/contatogrupoapi/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/contatogrupoapi/5
        public void Delete(int id)
        {
        }
    }
}
