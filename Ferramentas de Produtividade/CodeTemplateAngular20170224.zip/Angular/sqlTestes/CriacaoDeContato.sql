USE ProvaDeConceito
GO

DECLARE @NomeContato VARCHAR(50)
SELECT @NomeContato = 'Contato 20'

INSERT INTO [ProvaDeConceito].[dbo].[Contato]([Nome],[Email],[Telefone],[Situacao])
VALUES (@NomeContato,'email@ldsoft.com.br','(00) 00000-0000', 'T');

INSERT INTO [ProvaDeConceito].[dbo].[ContatoEndereco]([IdContato],[Logradouro],[CEP],[Bairro],[Cidade],[Estado],[Pais])
VALUES (
    (SELECT MAX(id) FROM [ProvaDeConceito].[dbo].[Contato] WHERE Nome LIKE @NomeContato)
    ,'Rua de Teste 6','00000-000','Centro','Teste de Cidade','RJ','Brasil');

INSERT INTO [ProvaDeConceito].[dbo].[ContatoGrupo]([IdGrupo],[IdContato])
VALUES (
    3, (SELECT MAX(id) FROM [ProvaDeConceito].[dbo].[Contato] WHERE Nome LIKE @NomeContato));
    
--UPDATE [ProvaDeConceito].[dbo].[Contato] SET Situacao = 'L' WHERE Situacao = 'A'