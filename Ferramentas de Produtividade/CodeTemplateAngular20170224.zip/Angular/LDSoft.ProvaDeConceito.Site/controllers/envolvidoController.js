﻿var envolvidoController = function ($scope, $http) {
    /* jshint validthis:true */
    var vm = this;

    vm.titulo = 'Lista de Envolvidos';
    vm.urlenvolvido = 'https://api.github.com/users';
    vm.usuarios = {};
    vm.obterUsuarios = function (inicio) {
        $http.get(vm.urlenvolvido + '?since=' + inicio)
            .success(function (result, status, headers, config) {
                vm.usuarios = result;
            });
    };

    vm.obterUsuarios(1);
}

//angular
//    .module('LDSoft.PoC')
//envolvidoController.$inject = ['$scope', '$http'];

var envolvidoDetalheController = function ($scope, $http, $routeParams) {
    /* jshint validthis:true */
    var vm = this;

    vm.titulo = 'Envolvido Detalhe';
    vm.urlenvolvido = 'https://api.github.com/users';
    vm.login = $routeParams.login;
    vm.usuario = {};
    vm.repositorios = {};

    // Obter detalhes do Envolvido
    $http.get(vm.urlenvolvido + '/' + vm.login)
        .success(function (result, status, headers, config) {
            vm.usuario = result;
        });

    // Listar repositórios do Envolvido
    $http.get(vm.urlenvolvido + '/' + vm.login + '/repos')
        .success(function (result, status, headers, config) {
            vm.repositorios = result;
        });
}



angular
    .module('LDSoft.PoC')
    .controller('envolvidoDetalheController', envolvidoDetalheController)
    .controller('envolvidoController', envolvidoController);