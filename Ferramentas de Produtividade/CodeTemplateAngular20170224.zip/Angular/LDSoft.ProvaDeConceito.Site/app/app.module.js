﻿angular.module('LDSoft.PoC',
[
    'ngRoute'
]);