﻿angular.module('LDSoft.PoC')
    .config([
      '$routeProvider', function ($routeProvider) {
          $routeProvider
              .when('/envolvido',
              {
                controller: 'envolvidoController',
                templateUrl: 'envolvido.html'
              })
              .when('/envolvido/:id',
              {
                controller: 'envolvidoDetalheController',
                templateUrl: 'envolvidoDetalhe.html'
              })
              .otherwise({
                redirectTo: '/'
              });
        }
    ]);