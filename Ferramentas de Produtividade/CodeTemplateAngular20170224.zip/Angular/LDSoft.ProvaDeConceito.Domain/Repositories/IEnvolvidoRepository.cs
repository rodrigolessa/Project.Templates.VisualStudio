﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LDSoft.Comum.Domain;
using LDSoft.ProvaDeConceito.Domain.Entities;

namespace LDSoft.ProvaDeConceito.Domain.Repositories
{
    public interface IEnvolvidoRepository : IRepository<Envolvido>
    {
    }
}