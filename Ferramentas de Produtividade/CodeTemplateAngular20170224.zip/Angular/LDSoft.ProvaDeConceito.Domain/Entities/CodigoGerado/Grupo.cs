using System;
using System.Collections.Generic;
using LDSoft.Comum.Infrastructure;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class Grupo : EntityBase
    {
        public Grupo()
        {
            this.Contatoes = new List<Contato>();
        }

        public int Id { get; set; }
        public string Titulo { get; set; }
        public string Descricao { get; set; }
        public string Situacao { get; set; }
        public virtual ICollection<Contato> Contatoes { get; set; }
    }
}
