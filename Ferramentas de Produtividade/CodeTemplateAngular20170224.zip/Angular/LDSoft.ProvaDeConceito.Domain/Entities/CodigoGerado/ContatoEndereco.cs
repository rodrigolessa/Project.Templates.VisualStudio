using System;
using System.Collections.Generic;
using LDSoft.Comum.Infrastructure;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class ContatoEndereco : EntityBase
    {
        public int Id { get; set; }
        public int IdContato { get; set; }
        public string Logradouro { get; set; }
        public string CEP { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string Estado { get; set; }
        public string Pais { get; set; }
        public virtual Contato Contato { get; set; }
    }
}
