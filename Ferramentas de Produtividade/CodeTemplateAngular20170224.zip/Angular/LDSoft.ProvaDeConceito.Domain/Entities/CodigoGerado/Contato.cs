using System;
using System.Collections.Generic;
using LDSoft.Comum.Infrastructure;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class Contato : EntityBase
    {
        public Contato()
        {
            this.ContatoEnderecoes = new List<ContatoEndereco>();
            this.Grupoes = new List<Grupo>();
        }

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
        public string Situacao { get; set; }
        public virtual ICollection<ContatoEndereco> ContatoEnderecoes { get; set; }
        public virtual ICollection<Grupo> Grupoes { get; set; }
    }
}
