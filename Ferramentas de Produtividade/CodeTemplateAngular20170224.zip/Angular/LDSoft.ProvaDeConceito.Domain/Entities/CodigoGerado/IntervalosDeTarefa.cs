using System;
using System.Collections.Generic;
using LDSoft.Comum.Infrastructure;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class IntervalosDeTarefa : EntityBase
    {
        public long Id { get; set; }
        public int IdTarefa { get; set; }
        public Nullable<System.DateTime> Inicio { get; set; }
        public Nullable<System.DateTime> Fim { get; set; }
        public virtual Tarefa Tarefa { get; set; }
    }
}
