using System;
using System.Collections.Generic;
using LDSoft.Comum.Infrastructure;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class Ponto : EntityBase
    {
        public Ponto()
        {
            this.Intervaloes = new List<Intervalo>();
        }

        public int Id { get; set; }
        public int IdFuncionario { get; set; }
        public System.DateTime Dia { get; set; }
        public Nullable<System.TimeSpan> Horas { get; set; }
        public virtual Funcionario Funcionario { get; set; }
        public virtual ICollection<Intervalo> Intervaloes { get; set; }
    }
}
