﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LDSoft.Comum.Infrastructure;
using LDSoft.ProvaDeConceito.Domain.Entities.Enum;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class Contato : EntityBase
    {
        [NotMapped]
        public virtual string DescricaoDaSituacao
        {
            get
            {
                if (!string.IsNullOrEmpty(this.Situacao))
                {
                    switch (Convert.ToChar(this.Situacao))
                    {
                        case (char)SituacaoContratoEnum.Bloqueado:
                            return SituacaoContratoEnum.Bloqueado.ToString();
                        case (char)SituacaoContratoEnum.BloqueadoPorInadimplencia:
                            return SituacaoContratoEnum.BloqueadoPorInadimplencia.ToString();
                        case (char)SituacaoContratoEnum.Cancelado:
                            return SituacaoContratoEnum.Cancelado.ToString();
                        case (char)SituacaoContratoEnum.Inadimplente:
                            return SituacaoContratoEnum.Inadimplente.ToString();
                        case (char)SituacaoContratoEnum.Liberado:
                            return SituacaoContratoEnum.Liberado.ToString();
                        case (char)SituacaoContratoEnum.Teste:
                            return SituacaoContratoEnum.Teste.ToString();
                    }
                }

                return string.Empty;
            }
        }

        public IEnumerable<string> Validar()
        {
            var validationResults = new List<string>();

            return validationResults;
        }
    }
}
