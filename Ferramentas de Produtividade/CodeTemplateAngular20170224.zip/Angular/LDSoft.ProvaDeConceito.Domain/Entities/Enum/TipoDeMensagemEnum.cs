﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    //TODO: Mover para o Domain do projeto Comum
    public enum TipoDeMensagemEnum
    {
        Warning = 0,
        Erros = 1,
        Success = 2,
        Information = 3
    }
}
