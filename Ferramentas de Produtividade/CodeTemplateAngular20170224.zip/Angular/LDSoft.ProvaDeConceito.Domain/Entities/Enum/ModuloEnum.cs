﻿using System.ComponentModel;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    //TODO: Transportar para projeto comun
    public enum ModuloEnum
    {
        [Description("Marca")]
        Marca = 'M',
        [Description("Patente")]
        Patente = 'P'
    }
}
