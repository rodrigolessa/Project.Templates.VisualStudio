﻿using System.ComponentModel;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    //TODO: Transportar para projeto comun
    public enum SubSistemaEnum
    {
        [Description("Jurisprudência")]
        Jurisprudencia = 'J',
        [Description("Estatística")]
        Estatistica = 'E',
        [Description("Anterioridade")]
        Anterioridade = 'A'
    }
}
