﻿using System.ComponentModel;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    //TODO: Transportar para projeto comun
    public enum TipoDePessoaEnum
    {
        [Description("Pessoa Física")]
        PessoaFisica = 'F',
        [Description("Pessoa Jurídica")]
        PessoaJuridica = 'J'
    }
}
