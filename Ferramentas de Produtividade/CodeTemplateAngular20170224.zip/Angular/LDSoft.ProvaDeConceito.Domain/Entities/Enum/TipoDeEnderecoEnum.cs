﻿using System.ComponentModel;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    public enum TipoDeEnderecoEnum
    {
        [Description("Principal")]
        Principal = 'P',
        [Description("Cobrança")]
        Cobranca = 'C',
        [Description("Outros")]
        Outros = 'O'
    }
}
