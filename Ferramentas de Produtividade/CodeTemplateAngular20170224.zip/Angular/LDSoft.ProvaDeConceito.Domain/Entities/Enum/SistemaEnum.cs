﻿using System.ComponentModel;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    //TODO: Transportar para projeto comun
    public enum SistemaEnum
    {
        [Description("Apol")]
        Apol = 'A',
        [Description("Webseek")]
        Webseek = 'W'
    }
}
