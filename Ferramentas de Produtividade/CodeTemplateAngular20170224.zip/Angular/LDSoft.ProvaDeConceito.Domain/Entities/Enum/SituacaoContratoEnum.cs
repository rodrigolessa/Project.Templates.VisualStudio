﻿using System.ComponentModel;

namespace LDSoft.ProvaDeConceito.Domain.Entities.Enum
{
    public enum SituacaoContratoEnum
    {
        [Description("Liberado")]
        Liberado = 'L',
        [Description("Teste")]
        Teste = 'T',
        [Description("Inadimplente")]
        Inadimplente = 'I',
        [Description("Bloqueado por inadimplência")]
        BloqueadoPorInadimplencia = 'D',
        [Description("Bloqueado")]
        Bloqueado = 'B',
        [Description("Cancelado")]
        Cancelado = 'C'
    }
}
