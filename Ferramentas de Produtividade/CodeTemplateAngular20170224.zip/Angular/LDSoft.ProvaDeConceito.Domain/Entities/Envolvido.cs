﻿using System;
using System.Collections.Generic;
using LDSoft.Comum.Infrastructure;
using LDSoft.Comum.Domain.Entities.ValueObjects;

namespace LDSoft.ProvaDeConceito.Domain.Entities
{
    public partial class Envolvido : EntityBase
    {
        public int Id { get; set; }
        public int IdUsuario { get; set; }

        public const int ApelidoMaxLength = 150;
        public string Apelido { get; set; }
        
        public Email Email { get; private set; }

        public const int RazaoSocialMaxLength = 150;
        public string RazaoSocial { get; set; }
        public string CNPJ { get; set; }

        public Cpf CPF { get; private set; }

        public const int PastaMaxLength = 30;
        public string Pasta { get; set; }

        public const int PessoaMaxLength = 10;
        public string Pessoa { get; set; }
        public Nullable<bool> DescontoINPI { get; set; }

        public string ObjetoSocial { get; set; }
        public string Observacao { get; set; }

        public const int NumeroDeRegistroMaxLength = 15;
        public string NumeroDeRegistro { get; set; }

        public Telefone Celular { get; private set; }

        public Endereco Endereco { get; private set; }

        public const int GrupoMaxLength = 15;
        public string Grupo { get; set; }

        public Nullable<int> IdAdvogado { get; set; }
        public Nullable<int> IdIdioma { get; set; }
        public Nullable<int> IdNacionalidade { get; set; }

        public int Status { get; set; }

        public DateTime DataDeInclusao { get; set; }
        public Nullable<DateTime> DataDeAlteracao { get; set; }


        // Para o EntityFramework
        protected Envolvido() { }

        public Envolvido(int idUsuario, string apelido, Email email, string razaoSocial, string cnpj, Cpf cpf, string pasta, string pessoa, bool? descontoINPI, string objetoSocial, string observacao, string numeroDeRegistro, Telefone celular, Endereco endereco, string grupo, int? idAdvogado, int? idIdioma, int? idNacionalidade, int status = 3)
        {
            this.IdUsuario = idUsuario;

            this.Apelido = apelido;
            
            SetEmail(email);

            this.RazaoSocial = razaoSocial;
            this.CNPJ = cnpj;

            SetCpf(cpf);

            this.Pasta = pasta;

            this.Pessoa = pessoa;
            this.DescontoINPI = descontoINPI;

            this.ObjetoSocial = objetoSocial;
            this.Observacao = observacao;

            this.NumeroDeRegistro = numeroDeRegistro;

            this.Celular = celular;

            this.Endereco = endereco;

            this.Grupo = grupo;

            this.IdAdvogado = idAdvogado;
            this.IdIdioma = idIdioma;
            this.IdNacionalidade = idNacionalidade;

            this.Status = status;

            this.DataDeInclusao = DateTime.Now;
        }

        public void SetCpf(Cpf cpf)
        {
            if (cpf == null)
                throw new Exception("CPF é obrigatório.");
            CPF = cpf;
        }

        public void SetEmail(Email email)
        {
            if (email == null)
                throw new Exception("E-mail é obrigatório.");
            Email = email;
        }
    }
}
