﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

using LDSoft.Comum.Infrastructure;
using LDSoft.Comum.Infrastructure.Logging;
using LDSoft.Comum.Infrastructure.Validator;
using LDSoft.Comum.Infrastructure.Entity;
using LDSoft.Comum.Infrastructure.Entity.Logging;
using LDSoft.Comum.Domain;
using LDSoft.Comum.Domain.Extensions;
using LDSoft.ProvaDeConceito.Domain.Entities;
using LDSoft.ProvaDeConceito.Domain.Repositories;
using LDSoft.ProvaDeConceito.Domain.Resources;

namespace LDSoft.ProvaDeConceito.Domain.Services
{
    public class ContatoService : IContatoService
    {
        #region Atributos

        //TODO: Refatorar para só utilizar o repositório do Cliente
        private readonly IQueryableUnitOfWork _unit;
        private readonly IContatoRepository _repository;
        private readonly IGrupoRepository _grupoRepository;
        private readonly IContatoEnderecoRepository _enderecoRepository;

        #endregion

        #region Construtor

        public ContatoService(
            IContatoRepository repository,
            IGrupoRepository grupoRepository,
            IContatoEnderecoRepository enderecoRepository,
            IQueryableUnitOfWork unit)
        {
            _unit = unit;
            _repository = repository;
            _grupoRepository = grupoRepository;
            _enderecoRepository = enderecoRepository;
        }

        #endregion

        public Contato Obter(int id)
        {
            return _repository.Get(id);
        }

        public List<Contato> Obter(string nome)
        {
            return _repository.GetFiltered(x => x.Nome.Contains(nome)).ToList();
        }

        public BusinessResponse<bool> Salvar(Contato contato)
        {
            throw new NotImplementedException();
        }

        public BusinessResponse<bool> Excluir(int id)
        {
            try
            {
                var contato = _repository.Get(id);
                if (contato == null)
                    return new BusinessResponse<bool>(false, Mensagens.ReturnGenericoNaoExiste);

                //HACK: Tentativa de excluir endereços do Contato para evitar erro de restrição de integridade no banco
                contato.ContatoEnderecoes.ToList().ForEach(end => _enderecoRepository.Remove(end));
                contato.Grupoes.Clear();//.ToList().ForEach( => _enderecoRepository.Remove(end));

                _repository.Remove(contato);

                _unit.Commit();

                //LogFactory.CreateLog().Gerar(
                //    Constants.Geral.Acao.Excluir,
                //    "Exclusão de Contato",
                //    string.Format(Mensagens.ReturnGenericoExcluidoSucesso, cliente.Nome),
                //    Constants.Geral.Sistema.Apol, null, null, cliente.Id);

                return new BusinessResponse<bool>(true, string.Format(Mensagens.ReturnGenericoExcluidoSucesso, contato.Nome));
            }
            catch (Exception ex)
            {
                //LogFactory.CreateLog().Gerar(
                //    Constants.Geral.Acao.Excluir,
                //    ex.Source,
                //    ex.Message,
                //    Constants.Geral.Sistema.Apol, null, null, null);

                return new BusinessResponse<bool>(false, string.Format(Mensagens.ReturnGenericoExcluirErro, ""));
            }
        }

        public BusinessResponse<bool> Excluir(List<int> ids)
        {
            var excluido = true;
            var erros = new List<string>();

            foreach (int id in ids)
            {
                var br = this.Excluir(id);
                if (br.Messages.HasErros())
                    br.Messages.ForEach(x => erros.Add(x));

                if (!br.Response)
                    excluido = false;
            }

            return new BusinessResponse<bool>(excluido, erros);
        }

        public BusinessResponse<bool> AssociarGrupos(List<int> ids, List<int> idGrupos)
        {
            foreach (int id in ids)
            {
                var cliente = _repository.Get(id);
                if (cliente != null)
                {
                    foreach (int idg in idGrupos)
                    {
                        if (!cliente.Grupoes.Where(x => x.Id == idg).Any())
                            cliente.Grupoes.Add(_grupoRepository.Get(idg));
                    }

                    _repository.Modify(cliente);
                }
            }

            if (_unit.Commit() > 0)
                return new BusinessResponse<bool>(true, Mensagens.ReturnGenericoAlteradoEmLoteSucesso);

            return new BusinessResponse<bool>(false, Mensagens.ReturnGenericoAlteradoEmLoteErro);
        }
    }
}
