﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LDSoft.ProvaDeConceito.Domain.Entities;
using LDSoft.Comum.Infrastructure;

namespace LDSoft.ProvaDeConceito.Domain.Services
{
    public interface IContatoService
    {
        Contato Obter(int id);
        List<Contato> Obter(string nome);

        BusinessResponse<Boolean> Salvar(Contato contato);
        BusinessResponse<Boolean> Excluir(int id);
        BusinessResponse<Boolean> Excluir(List<int> ids);
        BusinessResponse<Boolean> AssociarGrupos(List<int> ids, List<int> idGrupos);
    }
}
