﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sample.Kadastro.Infraestrutura.Comuns;
using $safeprojectname$.DTO;
using Sample.Kadastro.Dominio.Entities;

namespace $safeprojectname$
{
    public interface ITarefaAppService
    {
        List<TarefaDTO> Obter(string login);
        BusinessResponse<Boolean> Salvar(TarefaDTO item);
        BusinessResponse<Boolean> Excluir(Int32 id);
        BusinessResponse<Boolean> Executar(Int32 id);
    }
}
