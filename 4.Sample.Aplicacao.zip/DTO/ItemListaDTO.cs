﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace $safeprojectname$.DTO
{
    public class ItemListaDTO
    {
        public Int64 Id { get; set; }
        public string Descricao { get; set; }
    }
}
