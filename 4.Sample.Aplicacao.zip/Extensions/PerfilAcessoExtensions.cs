﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sample.Kadastro.Dominio.Entities.Enum;
using $safeprojectname$.DTO;

namespace $safeprojectname$.Extensions
{
    public static class PerfilAcessoExtensions
    {
        //public static List<ItemListaDTO> ToItemListaDTO(this List<PerfilAcesso> lista)
        //{
        //}

        //public static ItemListaDTO ToItemListaDTO(this PerfilAcesso item)
        //{
        //}
    }
}
