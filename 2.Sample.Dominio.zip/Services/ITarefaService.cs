﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Sample.Kadastro.Infraestrutura.Comuns;
using $safeprojectname$.Entities;
using $safeprojectname$.Entities.Enum;
using $safeprojectname$.Model;

namespace $safeprojectname$.Services
{
    public interface ITarefaService
    {
        List<Tarefa> Obter(string login);
        BusinessResponse<Boolean> Salvar(Tarefa item);
        BusinessResponse<Boolean> Excluir(Int32 id);
        BusinessResponse<Boolean> Executar(Int32 id);
    }
}
