﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using $safeprojectname$.Entities;

namespace $safeprojectname$.Repositories
{
    public interface IIntervaloRepository : IRepository<Intervalo>
    {
    }
}
